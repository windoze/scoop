"""Trace a real source update and the following unchanged build."""
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])
target = sys.argv[2]
label = sys.argv[3]
repo = Path.cwd()
case = next(root.glob('cases/*/normal/tools.json')).parent
cache = case / 'cache'
source = case / 'main.scoop'
assert source.read_text() == 'fun main(): Int = 48\n'
argv = [str(repo / 'target/release/scoop'), 'build', str(source), '--target', target,
        '--sysroot', str(root / 'sysroot'), '--scoopc', str(repo / 'target/release/scoopc'),
        '--cache-dir', str(cache), '--runtime-root', str(repo / 'runtime'),
        '--target-dir', str(case / 'target'), '--message-format', 'json',
        '--unwind-prefix', str(repo / 'sysroot/native' / target / 'unwind')]

def metadata(paths):
    return {str(p): [p.stat().st_size, p.stat().st_mtime_ns] for p in sorted(paths)}

def tools():
    return metadata(cache.glob('*-tools-v1/*.json'))

before = tools()
source.write_text('fun main(): Int = 49\n')
summary = {'argv': argv, 'source_update': [48, 49], 'requests': []}
for name, children in [('changed', 1), ('warm', 0)]:
    stem = Path(f'/tmp/scoop-m48-final-tools-{label}-{name}')
    trace = stem.with_suffix('.trace')
    generated = metadata([*cache.glob('executables-v1/program-*/program'),
                          *cache.glob('executables-v1/*.json')])
    result = subprocess.run(['strace', '-f', '-qq', '-s', '4096', '-e',
                             'trace=execve,openat,rename,renameat,renameat2', '-o', str(trace),
                             *argv], capture_output=True)
    stem.with_suffix('.stderr').write_bytes(result.stderr)
    assert result.returncode == 0, result.stderr.decode()
    records = [json.loads(line) for line in result.stderr.splitlines()]
    built = next(r for r in records if r.get('kind') == 'executable')
    assert len(built['observations']['child_invocations']) == children, built
    assert subprocess.run([built['output']]).returncode == 49
    lines = trace.read_text().splitlines()
    calls = [line for line in lines if 'execve(' in line]
    probes = [line for line in calls if any(flag in line for flag in
              ['-print-', '--version', '--verbose', 'scoop-elf-link-', 'link-probe', '-dM'])]
    assert not probes, probes
    assert before == tools(), 'tool discovery records changed'
    current = metadata([*cache.glob('executables-v1/program-*/program'),
                        *cache.glob('executables-v1/*.json')])
    if name == 'warm':
        assert current == generated
        assert len(calls) == 1, calls
        content = [line for line in lines if 'openat(' in line and any(
            suffix in line for suffix in ['.scoop"', '.slib"', '.h"', '.tbd"', '.o"', 'Cone.toml"'])]
        assert not content, content
    summary['requests'].append({'name': name, 'compiler_children': children,
        'execve_calls': calls, 'tool_records_unchanged': before == tools(),
        'generated_metadata_unchanged': current == generated, 'exit': 49})
Path(f'/tmp/scoop-m48-final-tools-{label}-trace-summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps({'target': target, 'execve_counts': [len(x['execve_calls']) for x in summary['requests']]}))
