import subprocess
from pathlib import Path
repo = Path('/Users/chenxu/repos/scoop')
names = ['m48-artifact-summary', 'program-link-basic', 'program-link-input-errors']
args = ['python3', 'tests/run_fixtures.py', '--scoop', 'target/release/scoop', '--scoopc', 'target/release/scoopc', '--scoop-link', 'target/release/scoop-link', '--target', 'aarch64-apple-darwin', '--jobs', '4', '--work-dir', 'target/m48-cold-entry-final-darwin', '--keep']
for name in names:
    args += ['--filter', name]
with Path('/tmp/scoop-m48-cold-entry-darwin-cli.log').open('w') as output:
    result = subprocess.run(args, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
print('exit:', result.returncode)
result.check_returncode()
