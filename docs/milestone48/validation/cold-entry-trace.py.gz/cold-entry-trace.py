"""Observe one real input update and the following cache hit."""
import json
import os
import re
import subprocess
from pathlib import Path

repo = Path.home() / 'repos/scoop'
base = repo / 'target/m48-isolation-validation'
logs = base / 'logs'
work = base / 'cold-entry-final-gnu-cli'
report = json.loads((work / 'report.json').read_text())
index = next(i for i, row in enumerate(report['results']) if row['name'] == 'm48-artifact-summary')
case = work / 'cases' / str(index) / 'normal'
artifact = case / 'provider.slib'
source = case / 'consumer/src/main.scoop'
original = source.read_text()
assert original.count('fun main(): Int = VALUE') == 1
source.write_text(original.replace('fun main(): Int = VALUE', 'fun main(): Int = VALUE + 1'))
os.utime(artifact, None)
with artifact.open('rb') as stream:
    header = stream.read(68)
manifest_end = 68 + int(header[56:66])
bins = repo / 'target/m48-summary-reader/release'
args = [str(bins/'scoop'), 'build', str(case/'consumer'), '--target', 'x86_64-unknown-linux-gnu',
        '--unwind-prefix', str(repo/'sysroot/native/x86_64-unknown-linux-gnu/unwind'),
        '--sysroot', str(work/'sysroot'), '--scoopc', str(bins/'scoopc'),
        '--cache-dir', str(case/'cache'), '--target-dir', str(case/'target'),
        '--runtime-root', str(repo/'runtime'), '--message-format', 'json', '-o', str(case/'program')]
results = []
for phase in ('cold', 'warm'):
    trace = logs / f'cold-entry-gnu-{phase}.trace'
    result = subprocess.run(['strace', '-f', '-yy', '-s', '128', '-e',
                             'trace=openat,read,pread64,lseek,close,execve', '-o', str(trace), *args], capture_output=True)
    (logs/f'cold-entry-gnu-{phase}.stderr').write_bytes(result.stderr)
    result.check_returncode()
    records = [json.loads(line) for line in result.stderr.splitlines()]
    built = next(row for row in records if row.get('kind') == 'executable')
    lines = trace.read_text().splitlines()
    parent = next(re.match(r'^(\d+)\s+execve\(', line)[1] for line in lines
                  if 'execve("'+str(bins/'scoop')+'"' in line)
    opens = 0
    positions = {}
    ranges = []
    for line in lines:
        if not line.startswith(parent+' '): continue
        if 'openat(' in line and '"'+str(artifact)+'"' in line: opens += 1
        if str(artifact)+'>' not in line: continue
        match = re.search(r'^\d+\s+(read|pread64|lseek)\((\d+)<', line)
        if not match: continue
        operation, fd = match.groups()
        returned = re.search(r'= (\d+)\s*$', line)
        assert returned, line
        count = int(returned[1])
        if operation == 'lseek': positions[fd] = count
        else:
            assert operation == 'read', line
            start = positions.get(fd, 0)
            if count: ranges.append((start, start+count))
            positions[fd] = start+count
    ranges.sort()
    assert all(left[1] <= right[0] for left, right in zip(ranges, ranges[1:]))
    manifest_read = sum(min(end,manifest_end)-start for start,end in ranges if start < manifest_end)
    child_count = len(built['observations']['child_invocations'])
    if phase == 'cold': assert opens == 1 and manifest_read == manifest_end and child_count == 1
    else: assert opens == 0 and not ranges and child_count == 0
    run = subprocess.run([str(case/'program')], capture_output=True)
    assert run.returncode == 50 and not run.stdout and not run.stderr
    results.append({'phase':phase, 'parent_pid':parent, 'artifact':str(artifact),
                    'opens':opens, 'bytes_read':sum(end-start for start,end in ranges),
                    'manifest_end':manifest_end, 'manifest_bytes_read':manifest_read,
                    'overlapping_reads':False, 'compiler_children':child_count, 'program_exit':run.returncode})
summary = {'argv':args, 'results':results,
           'scope':'Parent discovery and actual link consumption share the cold artifact input; the following unchanged build does not open it. Compiler children may independently read needed dependency data.'}
(logs/'cold-entry-gnu-io.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary, indent=2))
