import os,subprocess
from pathlib import Path
repo=Path('/home/chenxu/repos/scoop')
base=repo/'target/m48-isolation-validation'
logs=base/'logs'
target='target/m48-summary-reader'
def run(tag,args):
 path=logs/('provider-data-'+tag+'.log')
 print('Starting '+tag,flush=True)
 with path.open('w') as output: result=subprocess.run(args,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
 print(tag+': exit='+str(result.returncode)+'\n'+'\n'.join(path.read_text().splitlines()[-4:]),flush=True)
 result.check_returncode()
run('linux-fmt',['cargo','fmt','--all','--check'])
run('linux-clippy',['cargo','clippy','--workspace','--all-targets','--target-dir',target,'-j','2'])
run('linux-shape',['cargo','test','-p','scoop-lir','--lib','shape_link','--target-dir',target,'-j','2'])
run('linux-closure',['cargo','test','-p','scoop-slib','--lib','link_object::layout','--target-dir',target,'-j','2'])
run('linux-release',['cargo','build','--release','-p','scoop','-p','scoopc','-p','scoop-linker','--bins','--target-dir',target,'-j','2'])
os.environ['SCOOP_TEST_PAIRED_SCOOPC']=str(repo/target/'release/scoopc')
run('linux-generic',['cargo','test','-p','scoopc','--lib','actual_generic_library_emits_shared_odr_objects','--target-dir',target,'-j','2'])
names=['generic-siblings-combined','generic-siblings-adapters-combined','generic-odr-conflicts-conflict','program-link-basic','runtime-images-ordinary','runtime-images-schedule-root','imported-class-combined','imported-class-structural-box-combined','imported-class-initialization-combined','imported-class-interface-parent','imported-class-property-updates','imported-class-value-interface-enum','m33-native-c-artifacts','m46-serialize-artifacts','m43-test-purpose-generated','m48-object-files']
for label in ('gnu','musl'):
 work=base/('provider-data-final-'+label+'-cli')
 args=['python3','tests/run_fixtures.py','--scoop',target+'/release/scoop','--scoopc',target+'/release/scoopc','--scoop-link',target+'/release/scoop-link','--target','x86_64-unknown-linux-'+label,'--jobs','3','--work-dir',str(work),'--keep']
 for name in names: args+=['--filter',name]
 run(label+'-cli',args)
 (logs/('provider-data-'+label+'-cli.json')).write_bytes((work/'report.json').read_bytes())
