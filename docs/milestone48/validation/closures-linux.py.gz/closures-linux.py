import os
import subprocess
from pathlib import Path

repo = Path.home() / 'repos/scoop'
base = repo / 'target/m48-isolation-validation'
logs = base / 'logs'
target = 'target/m48-summary-reader'
names = ['program-link-basic', 'program-link-artifact-graph', 'program-link-input-errors', 'm48-object-files', 'runtime-images-empty', 'runtime-images-ordinary', 'runtime-images-schedule-root', 'generic-siblings-combined', 'generic-siblings-adapters-combined', 'generic-odr-conflicts-conflict', 'generic-odr-conflicts-strings-conflict', 'm33-main-args-int', 'm46-serialize-artifacts', 'm33-native-c-artifacts', 'm33-native-cxx-artifacts', 'm33-gc-leaf-artifacts', 'm43-test-purpose-generated']

def run(tag, args):
    path = logs / f'closures-{tag}.log'
    print(f'Starting {tag}', flush=True)
    with path.open('w') as output:
        result = subprocess.run(args, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
    print(f'{tag}: exit={result.returncode}\n' + '\n'.join(path.read_text().splitlines()[-4:]), flush=True)
    result.check_returncode()

run('linux-fmt', ['cargo', 'fmt', '--all', '--check'])
run('linux-clippy', ['cargo', 'clippy', '--workspace', '--all-targets', '--target-dir', target, '-j', '2'])
run('linux-release', ['cargo', 'build', '--release', '--target-dir', target, '-j', '2', '-p', 'scoop', '-p', 'scoopc', '-p', 'scoop-linker', '--bins'])
os.environ['SCOOP_TEST_PAIRED_SCOOPC'] = str(repo / target / 'release/scoopc')
run('linux-slib', ['cargo', 'test', '-p', 'scoop-slib', '-p', 'scoop-protocol', '--lib', '--target-dir', target, '-j', '2'])
run('linux-generic', ['cargo', 'test', '-p', 'scoopc', '--lib', '--target-dir', target, '-j', '2', 'actual_generic_library_emits_shared_odr_objects'])
run('linux-layout', ['cargo', 'test', '-p', 'scoopc', '--lib', '--target-dir', target, '-j', '2', 'actual_core_sources_produce_closed_mir_and_lir_export_tables'])
for label in ('gnu', 'musl'):
    work = base / f'closures-final-{label}-cli'
    args = ['python3', 'tests/run_fixtures.py', '--scoop', target + '/release/scoop',
            '--scoopc', target + '/release/scoopc', '--scoop-link', target + '/release/scoop-link',
            '--target', f'x86_64-unknown-linux-{label}', '--jobs', '3', '--work-dir', str(work), '--keep']
    for name in names:
        args += ['--filter', name]
    run(label + '-cli', args)
    (logs / f'closures-{label}-cli.json').write_bytes((work / 'report.json').read_bytes())
