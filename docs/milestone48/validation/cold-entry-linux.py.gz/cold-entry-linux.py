import os
import subprocess
from pathlib import Path

repo = Path.home() / 'repos/scoop'
base = repo / 'target/m48-isolation-validation'
logs = base / 'logs'
target = 'target/m48-summary-reader'
names = ['m48-artifact-summary', 'program-link-basic', 'program-link-input-errors']

def run(tag, args):
    path = logs / f'cold-entry-{tag}.log'
    print(f'Starting {tag}', flush=True)
    with path.open('w') as output:
        result = subprocess.run(args, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
    print(f'{tag}: exit={result.returncode}\n' + '\n'.join(path.read_text().splitlines()[-4:]), flush=True)
    result.check_returncode()

run('linux-fmt', ['cargo', 'fmt', '--all', '--check'])
run('linux-clippy', ['cargo', 'clippy', '--workspace', '--all-targets', '--target-dir', target, '-j', '2'])
run('linux-release', ['cargo', 'build', '--release', '--target-dir', target, '-j', '2', '-p', 'scoop', '-p', 'scoopc', '-p', 'scoop-linker', '--bins'])
run('linux-unit', ['cargo', 'test', '-p', 'scoop', '--lib', '--target-dir', target, '-j', '2'])
for label in ('gnu', 'musl'):
    work = base / f'cold-entry-final-{label}-cli'
    args = ['python3', 'tests/run_fixtures.py', '--scoop', target + '/release/scoop',
            '--scoopc', target + '/release/scoopc', '--scoop-link', target + '/release/scoop-link',
            '--target', f'x86_64-unknown-linux-{label}', '--jobs', '3', '--work-dir', str(work), '--keep']
    for name in names:
        args += ['--filter', name]
    run(label + '-cli', args)
    (logs / f'cold-entry-{label}-cli.json').write_bytes((work / 'report.json').read_bytes())
