import os
import subprocess
from pathlib import Path

repo = Path.home() / 'repos/scoop'
base = repo / 'target/m48-isolation-validation'
logs = base / 'logs'
target = 'target/m48-summary-reader'
names = ['program-link-basic', 'program-link-artifact-graph', 'program-link-input-errors',
         'm48-object-files', 'm33-native-c-artifacts', 'm33-gc-leaf-artifacts',
         'generic-odr-conflicts-conflict', 'm46-serialize-artifacts',
         'm43-test-purpose-generated']

def run(tag, args):
    path = logs / f'link-file-{tag}.log'
    print(f'Starting {tag}', flush=True)
    with path.open('w') as output:
        result = subprocess.run(args, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
    print(f'{tag}: exit={result.returncode}\n' + '\n'.join(path.read_text().splitlines()[-4:]), flush=True)
    result.check_returncode()

run('linux-fmt', ['cargo', 'fmt', '--all', '--check'])
run('linux-clippy', ['cargo', 'clippy', '--workspace', '--all-targets', '--target-dir', target, '-j', '2'])
run('linux-release', ['cargo', 'build', '--release', '--target-dir', target, '-j', '2', '-p', 'scoop', '-p', 'scoopc', '-p', 'scoop-linker', '--bins'])
os.environ['SCOOP_TEST_PAIRED_SCOOPC'] = str(repo / target / 'release/scoopc')
run('linux-scoop', ['cargo', 'test', '-p', 'scoop', '--lib', '--target-dir', target, '-j', '2'])
run('linux-linker', ['cargo', 'test', '-p', 'scoop-linker', '--lib', '--target-dir', target, '-j', '2'])
run('linux-program', ['cargo', 'test', '-p', 'scoopc', '--target-dir', target, '-j', '2', 'program_link_reads_machine_data_from_actual_executable_artifacts'])
for label in ('gnu', 'musl'):
    work = base / f'link-file-{label}-cli'
    args = ['python3', 'tests/run_fixtures.py', '--scoop', target + '/release/scoop',
            '--scoopc', target + '/release/scoopc', '--scoop-link', target + '/release/scoop-link',
            '--target', f'x86_64-unknown-linux-{label}', '--jobs', '3', '--work-dir', str(work), '--keep']
    for name in names:
        args += ['--filter', name]
    run(label + '-cli', args)
    (logs / f'link-file-{label}-cli.json').write_bytes((work / 'report.json').read_bytes())
