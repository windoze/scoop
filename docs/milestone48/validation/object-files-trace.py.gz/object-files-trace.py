"""Observe real relinks while retaining all inputs and existing outputs."""

import json
import re
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])
target = sys.argv[2]
label = sys.argv[3]
repo = Path.cwd()
bin_dir = repo / "target/release"
target_args = [
    "--target",
    target,
    "--sysroot",
    str(root / "sysroot"),
    "--unwind-prefix",
    str(repo / "sysroot/native" / target / "unwind"),
]


def metadata(cache):
    return {
        str(p): [p.stat().st_size, p.stat().st_mtime_ns]
        for p in sorted((cache / "objects-v1").glob("*.o"))
    }


def check(case, source, native, expected, name):
    cache = case / "cache"
    library_args = (
        ["--library-path", str(case / "native"), "--library-path", str(case / "extra")]
        if native
        else []
    )
    build_args = [
        str(bin_dir / "scoop"),
        "build",
        str(source),
        *target_args,
        "--scoopc",
        str(bin_dir / "scoopc"),
        "--cache-dir",
        str(cache),
        "--runtime-root",
        str(repo / "runtime"),
        "--target-dir",
        str(case / "target"),
        "--message-format",
        "json",
        *library_args,
    ]
    stem = Path(f"/tmp/scoop-m48-object-files-{label}-{name}")
    prepared = subprocess.run(build_args, capture_output=True)
    stem.with_suffix(".prepare.stderr").write_bytes(prepared.stderr)
    assert prepared.returncode == 0, prepared.stderr.decode()
    built = subprocess.run(build_args, capture_output=True)
    stem.with_suffix(".build.stderr").write_bytes(built.stderr)
    assert built.returncode == 0, built.stderr.decode()
    records = [json.loads(line) for line in built.stderr.splitlines()]
    result = next(r for r in records if r.get("kind") == "executable")
    assert len(result["observations"]["child_invocations"]) == 0, result
    assert subprocess.run([result["output"]]).returncode == expected
    argv = [
        str(bin_dir / "scoop-link"),
        *target_args,
        "--cache-dir",
        str(cache),
        "--root-slib",
        result["root"]["path"],
    ]
    for dependency in result["dependencies"]:
        argv.extend(["--dep-slib", dependency["path"]])
    argv.extend(
        [
            "--runtime-objects",
            result["runtime_index"],
            *library_args,
            "-o",
            str(case / "trace-linked"),
        ]
    )
    before = metadata(cache)
    assert before
    trace = stem.with_suffix(".trace")
    linked = subprocess.run(
        [
            "strace",
            "-f",
            "-qq",
            "-s",
            "4096",
            "-e",
            "trace=execve,openat,rename,renameat,renameat2",
            "-o",
            str(trace),
            *argv,
        ],
        capture_output=True,
    )
    stem.with_suffix(".stdout").write_bytes(linked.stdout)
    stem.with_suffix(".stderr").write_bytes(linked.stderr)
    assert linked.returncode == 0, linked.stderr.decode()
    assert subprocess.run([str(case / "trace-linked")]).returncode == expected
    assert before == metadata(cache), "object files were created or rewritten"
    lines = trace.read_text().splitlines()
    executions = [line for line in lines if "execve(" in line]
    linker_pids = set()
    for line in executions:
        match = re.match(r'(\d+)\s+execve\("([^\"]+)"', line)
        if match and re.search(r"(^|-)ld(?:\.bfd|\.lld|\.gold)?$", Path(match[2]).name):
            linker_pids.add(match[1])
    assert linker_pids, executions
    opened = [line for line in lines if "openat(" in line and line.split()[0] in linker_pids]
    stable = [line for line in opened if "/objects-v1/" in line and '.o"' in line]
    assert stable, "native linker did not open stable Scoop objects"
    assert not any("O_CREAT" in line for line in lines if "/objects-v1/" in line)
    assert not any(re.search(r"/\.scoop-link-[^/]+/(cone-|native-)", line) for line in lines)
    original = []
    if native:
        candidates = [case / "alternative.o", case / "extra/value.o"]
        original = [line for line in opened if any(str(p) in line for p in candidates)]
        assert original, "native linker did not consume the original native object"
    return {
        "name": name,
        "build_argv": build_args,
        "link_argv": argv,
        "compiler_children": 0,
        "execve_calls": executions,
        "stable_object_files": len(before),
        "stable_object_opens": len(stable),
        "objects_metadata_unchanged": True,
        "temporary_cone_or_native_objects": False,
        "original_native_opens": original,
        "exit": expected,
    }


object_case = next(root.glob("cases/*/normal/imported.json")).parent
native_case = next(root.glob("cases/*/normal/alternative.o")).parent
results = [
    check(object_case, object_case / "program-source", False, 43, "relink"),
    check(
        native_case, repo / "tests/fixtures/m48-executable-native/main.scoop", True, 42, "native"
    ),
]
Path(f"/tmp/scoop-m48-object-files-{label}-trace-summary.json").write_text(
    json.dumps({"target": target, "requests": results}, indent=2) + "\n"
)
print(
    json.dumps(
        {"target": target, "stable_object_opens": [r["stable_object_opens"] for r in results]}
    )
)
