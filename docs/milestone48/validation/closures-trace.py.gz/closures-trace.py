import json
import re
import subprocess
from pathlib import Path

repo = Path.home() / 'repos/scoop'
base = repo / 'target/m48-isolation-validation'
work = base / 'closures-final-gnu-cli'
logs = base / 'logs'
report = json.loads((work / 'report.json').read_text())
index = next(i for i,r in enumerate(report['results']) if r['name'] == 'program-link-basic')
case = work / 'cases' / str(index) / 'normal'
bin_dir = repo / 'target/m48-summary-reader/release'
options = ['--target', 'x86_64-unknown-linux-gnu', '--sysroot', str(work/'sysroot'),
           '--unwind-prefix', str(repo/'sysroot/native/x86_64-unknown-linux-gnu/unwind'),
           '--cache-dir', str(work/'cache'), '--message-format', 'json']
build = subprocess.run([str(bin_dir/'scoop'), 'build', str(case/'sources/root'), *options,
                        '--scoopc', str(bin_dir/'scoopc'), '--runtime-root', str(repo/'runtime'),
                        '--target-dir', str(case/'target-build')], capture_output=True)
(logs/'closures-gnu-prepare.stderr').write_bytes(build.stderr)
build.check_returncode()
built = next(json.loads(line) for line in build.stderr.splitlines() if json.loads(line).get('kind') == 'executable')
assert built['observations']['child_invocations'] == []
paths = [case/'artifacts'/name for name in ('root.slib','0.slib','1.slib')]
args = [str(bin_dir/'scoop'), 'link', '--root-slib', str(paths[0]), *options,
        '--runtime-objects', built['runtime_index'], '-o', str(case/'trace-linked')]
for path in paths[1:]: args += ['--dependency-slib', str(path)]
trace = logs/'closures-gnu-link.trace'
result = subprocess.run(['strace','-f','-yy','-s','128','-e',
                         'trace=openat,read,pread64,lseek,close,execve','-o',str(trace),*args],capture_output=True)
(logs/'closures-gnu-link.stderr').write_bytes(result.stderr)
result.check_returncode()
run = subprocess.run([str(case/'trace-linked')],capture_output=True)
run.check_returncode()
assert run.stdout == b'42\n' and run.stderr == b''
rows = []
lines = trace.read_text().splitlines()
compiler_children = sum(bool(re.search(r'execve\("[^"]*/scoopc"', line)) for line in lines)
assert compiler_children == 0
for path in paths:
    opens = sum('openat(' in line and '"'+str(path)+'"' in line for line in lines)
    positions = {}
    ranges = []
    for line in lines:
        if str(path)+'>' not in line: continue
        match = re.search(r'^(\d+)\s+(read|lseek|pread64)\((\d+)<',line)
        if not match: continue
        pid,operation,fd = match.groups()
        returned = re.search(r'= (\d+)\s*$',line)
        assert returned, line
        count = int(returned[1]); key = (pid,fd)
        if operation == 'lseek': positions[key] = count
        else:
            assert operation == 'read', line
            start = positions.get(key,0)
            if count: ranges.append((start,start+count))
            positions[key] = start+count
    ranges.sort()
    assert opens == 1 and ranges
    assert all(previous[1] <= current[0] for previous,current in zip(ranges,ranges[1:]))
    with path.open('rb') as stream:
        header=stream.read(68)
    manifest_end=68+int(header[56:66])
    manifest_reads=sum(min(end,manifest_end)-start for start,end in ranges if start < manifest_end)
    assert manifest_reads == manifest_end
    machine = []
    metadata = []
    with path.open('rb') as stream:
        cursor = manifest_end + (manifest_end & 1)
        while cursor < path.stat().st_size:
            stream.seek(cursor)
            header = stream.read(60)
            length = int(header[48:58])
            end = cursor + 60 + length + (length & 1)
            if stream.read(4) == b'\x7fELF':
                machine.append((cursor, end))
            else:
                metadata.append((cursor, end))
            cursor = end
    assert len(metadata) == 3 and machine
    assert all(end <= begin or start >= finish for start,end in ranges for begin,finish in machine)
    assert sum(end-start for start,end in ranges) == manifest_end + sum(end-start for start,end in metadata)
    rows.append({'path':str(path),'artifact_bytes':path.stat().st_size,'opens':opens,
                 'bytes_read':sum(end-start for start,end in ranges),'manifest_end':manifest_end,
                 'manifest_bytes_read':manifest_reads,'overlapping_reads':False, 'machine_members':len(machine), 'machine_member_bytes_read':0})
summary={'argv':args,'compiler_children':compiler_children,'program_stdout':run.stdout.decode(),'artifacts':rows,
         'scope':'Explicit link reuses existing object files; only manifest and three metadata members are read from each artifact.'}
(logs/'closures-gnu-link.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
