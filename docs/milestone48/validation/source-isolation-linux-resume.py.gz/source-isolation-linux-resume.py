import json
import shutil
import subprocess
from pathlib import Path

repo = Path.home() / "repos/scoop"
base = repo / "target/m48-isolation-validation"
names = json.loads(Path("/tmp/scoop-m48-isolation-impacted-names.json").read_text())
reader = [
    "cli-core-default-source-and-artifact",
    "cli-derived-equality-provider-reexport",
    "program-link-input-errors",
    "m48-object-files",
    "m48-executable-record",
    "m33-native-c-artifacts",
    "m33-native-cxx-artifacts",
    "m43-test-artifact-dependencies",
    "m46-serialize-artifacts",
    "m46-values-artifacts",
    "core-layouts-shared-digests-combined",
    "imported-class-conformance-interface-cycle",
]


def run(label, target, selected, tag):
    work = base / (
        f"source-isolation-{label}-resume" if tag.startswith("source-isolation-") else tag
    )
    log = base / "logs" / f"{tag}.log"
    args = [
        "python3",
        "tests/run_fixtures.py",
        "--scoop",
        "target/release/scoop",
        "--scoopc",
        "target/release/scoopc",
        "--scoop-link",
        "target/release/scoop-link",
        "--target",
        target,
        "--jobs",
        "6",
        "--work-dir",
        str(work),
        "--keep",
    ]
    for name in selected:
        args += ["--filter", name]
    print(f"Starting {tag}: {len(selected)} selections", flush=True)
    with log.open("w") as output:
        code = subprocess.call(args, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
    print(f"{tag}: exit={code}", flush=True)
    print("\n".join(log.read_text().splitlines()[-3:]), flush=True)
    if code:
        raise SystemExit(code)
    report = json.loads((work / "report.json").read_text())
    (base / "logs" / f"{tag}.json").write_text(json.dumps(report, indent=2) + "\n")
    # All children have completed; retain reports and clear their temporary files.
    shutil.rmtree(work / "cases", ignore_errors=True)
    return report


reader_results = {}
for label, target in [("gnu", "x86_64-unknown-linux-gnu"), ("musl", "x86_64-unknown-linux-musl")]:
    reader_results[label] = run(label, target, reader, f"reader-hashes-{label}-cli")

for label, target in [("gnu", "x86_64-unknown-linux-gnu"), ("musl", "x86_64-unknown-linux-musl")]:
    done = set(json.loads((base / f"{label}-passed-first.json").read_text()))
    done.update(
        row["name"] for row in reader_results[label]["results"] if row["status"] == "passed"
    )
    remaining = [name for name in names if name not in done]
    reports = []
    for offset in range(0, len(remaining), 200):
        tag = f"source-isolation-{label}-resume-{offset // 200 + 1:02}"
        reports.append(run(label, target, remaining[offset : offset + 200], tag))
    (base / "logs" / f"source-isolation-{label}-resume.json").write_text(json.dumps(reports) + "\n")
