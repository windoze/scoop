import json
import subprocess
from pathlib import Path
repo = Path.home() / "repos/scoop"
base = repo / "target/m48-isolation-validation"
names = ['cli-core-locator-cache', 'cli-process-library', 'cli-process-source-observations', 'core-dependencies-missing', 'core-dependencies-ordinary', 'm33-sysroot-reject-ambiguous', 'm33-sysroot-reject-artifact-failure', 'm33-sysroot-reject-cycle', 'm33-sysroot-reject-executable', 'm33-sysroot-reject-group', 'm33-sysroot-reject-malformed', 'm33-sysroot-reject-missing', 'm33-sysroot-reject-name', 'm33-sysroot-reject-other-group', 'm33-sysroot-reject-search-failure', 'm33-sysroot-reject-source-failure', 'm33-sysroot-reject-undeclared', 'm33-sysroot-reject-version', 'm46-serialize-artifacts', 'm48-artifact-summary', 'program-link-input-errors']
for label in ("gnu", "musl"):
    work = base / f"artifact-record-{label}-cli"
    log = base / "logs" / f"artifact-record-{label}-cli.log"
    args = ["python3", "tests/run_fixtures.py", "--scoop", "target/m48-summary-reader/release/scoop", "--scoopc", "target/m48-summary-reader/release/scoopc", "--scoop-link", "target/m48-summary-reader/release/scoop-link", "--target", f"x86_64-unknown-linux-{label}", "--jobs", "3", "--work-dir", str(work), "--keep"]
    for name in names:
        args += ["--filter", name]
    print(f"Starting {label}: {len(names)} selections", flush=True)
    with log.open("w") as output:
        result = subprocess.run(args, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
    print(f"{label}: exit={result.returncode}", flush=True)
    print("\n".join(log.read_text().splitlines()[-4:]), flush=True)
    result.check_returncode()
    (base / "logs" / f"artifact-record-{label}-cli.json").write_bytes((work / "report.json").read_bytes())
