import json
import re
import subprocess
from pathlib import Path

repo = Path.home() / "repos/scoop"
base = repo / "target/m48-isolation-validation"
work = base / "artifact-record-gnu-cli"
report = json.loads((work / "report.json").read_text())
index = next(
    i for i, row in enumerate(report["results"]) if row["name"] == "cli-core-locator-cache"
)
case = work / "cases" / str(index) / "normal"
artifact = case / "core.slib"
with artifact.open("rb") as stream:
    header = stream.read(68)
expected = 68 + int(header[56:66])
args = [
    str(repo / "target/m48-summary-reader/release/scoop"),
    "build",
    "--target",
    "x86_64-unknown-linux-gnu",
    "--unwind-prefix",
    str(repo / "sysroot/native/x86_64-unknown-linux-gnu/unwind"),
    str(case / "sources/root"),
    "--sysroot",
    str(work / "sysroot"),
    "--scoopc",
    str(repo / "target/m48-summary-reader/release/scoopc"),
    "--cache-dir",
    str(case / "cache"),
    "--target-dir",
    str(case / "target"),
    "--message-format",
    "json",
    "--runtime-root",
    str(repo / "runtime"),
    "-o",
    str(case / "library.slib"),
]
warm = subprocess.run(args, cwd=case, capture_output=True)
(base / "logs/artifact-record-gnu-prime.stderr").write_bytes(warm.stderr)
warm.check_returncode()
def record_state():
    return {str(p): (p.stat().st_size, p.stat().st_mtime_ns) for p in (case / "cache/artifact-summaries-v1").glob("*.cbor")}
before = record_state()
assert before
trace = base / "logs/artifact-record-gnu-warm.trace"
result = subprocess.run(
    [
        "strace",
        "-f",
        "-yy",
        "-s",
        "128",
        "-e",
        "trace=openat,read,pread64,lseek,close,execve",
        "-o",
        str(trace),
        *args,
    ],
    cwd=case,
    capture_output=True,
)
(base / "logs/artifact-record-gnu-warm.stderr").write_bytes(result.stderr)
result.check_returncode()
records = [json.loads(line) for line in result.stderr.splitlines()]
reads = [
    line
    for line in trace.read_text().splitlines()
    if str(artifact) + ">" in line and re.search(r"\b(?:read|pread64)\(", line)
]
read_bytes = sum(int(re.search(r"= (\d+)\s*$", line)[1]) for line in reads)
opens = [
    line
    for line in trace.read_text().splitlines()
    if "openat(" in line and '"' + str(artifact) + '"' in line
]
summary = {
    "argv": args,
    "artifact": str(artifact),
    "artifact_bytes": artifact.stat().st_size,
    "manifest_end": expected,
    "bytes_read": read_bytes,
    "opens": len(opens),
    "summary_records": len(before),
    "summary_records_unchanged": before == record_state(),
    "child_invocations": records[-1]["observations"]["child_invocations"],
}
(base / "logs/artifact-record-gnu-warm.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
assert read_bytes == 0 and before == record_state()
assert len(opens) == 0 and not summary["child_invocations"]
