import subprocess
from pathlib import Path
repo = Path('/Users/chenxu/repos/scoop')
names = ['program-link-basic', 'program-link-artifact-graph', 'program-link-input-errors', 'm48-object-files', 'runtime-images-empty', 'runtime-images-ordinary', 'runtime-images-schedule-root', 'generic-siblings-combined', 'generic-siblings-adapters-combined', 'generic-odr-conflicts-conflict', 'generic-odr-conflicts-strings-conflict', 'm33-main-args-int', 'm46-serialize-artifacts', 'm33-native-c-artifacts', 'm33-native-cxx-artifacts', 'm33-gc-leaf-artifacts', 'm43-test-purpose-generated']
args = ['python3', 'tests/run_fixtures.py', '--scoop', 'target/release/scoop', '--scoopc', 'target/release/scoopc', '--scoop-link', 'target/release/scoop-link', '--target', 'aarch64-apple-darwin', '--jobs', '4', '--work-dir', 'target/m48-closures-final-darwin', '--keep']
for name in names:
    args += ['--filter', name]
with Path('/tmp/scoop-m48-closures-darwin-cli.log').open('w') as output:
    result = subprocess.run(args, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
print('exit:', result.returncode)
result.check_returncode()
