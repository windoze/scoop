import os
import subprocess
from pathlib import Path
repo = Path('/Users/chenxu/repos/scoop')
def run(tag, args):
    path = Path('/tmp/scoop-m48-link-inputs-' + tag + '.log')
    print('Starting ' + tag, flush=True)
    with path.open('w') as output:
        result = subprocess.run(args, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
    print(tag + ': exit=' + str(result.returncode) + '\n' + '\n'.join(path.read_text().splitlines()[-4:]), flush=True)
    result.check_returncode()
run('darwin-slib', ['cargo','test','-p','scoop-slib','--lib'])
run('darwin-entry', ['cargo','test','-p','scoop-lir','--lib','production::entry::tests'])
run('darwin-release', ['cargo','build','--release','-p','scoop','-p','scoopc','-p','scoop-linker','--bins'])
os.environ['SCOOP_TEST_PAIRED_SCOOPC'] = str(repo/'target/release/scoopc')
run('darwin-linker', ['cargo','test','-p','scoop-linker','--lib'])
run('darwin-program-link', ['cargo','test','-p','scoopc','--lib','program_link_reads_machine_data_from_actual_executable_artifacts'])
names = ['program-link-basic', 'program-link-artifact-graph', 'program-link-input-errors', 'm48-object-files', 'runtime-images-empty', 'runtime-images-ordinary', 'runtime-images-schedule-root', 'generic-siblings-combined', 'generic-siblings-adapters-combined', 'generic-odr-conflicts-conflict', 'generic-odr-conflicts-strings-conflict', 'm33-main-args-int', 'm46-serialize-artifacts', 'm33-native-c-artifacts', 'm33-native-cxx-artifacts', 'm33-gc-leaf-artifacts', 'm43-test-purpose-generated']
args = ['python3', 'tests/run_fixtures.py', '--scoop', 'target/release/scoop', '--scoopc', 'target/release/scoopc', '--scoop-link', 'target/release/scoop-link', '--target', 'aarch64-apple-darwin', '--jobs', '4', '--work-dir', 'target/m48-link-inputs-final-darwin', '--keep']
for name in names:
    args += ['--filter', name]
run('darwin-cli', args)
