import json
import re
import subprocess
from pathlib import Path

repo = Path.home() / 'repos/scoop'
base = repo / 'target/m48-isolation-validation'
work = base / 'file-reader-gnu-cli'
report = json.loads((work / 'report.json').read_text())
index = next(i for i, row in enumerate(report['results']) if row['name'] == 'cli-core-locator-cache')
case = work / 'cases' / str(index) / 'normal'
artifact = case / 'core.slib'
trace_work = base / 'file-reader-trace'
trace_work.mkdir(exist_ok=True)
(trace_work / 'Cone.toml').write_text('schema = 1\n[cone]\ngroup = "test"\nname = "file-reader-trace"\nversion = "1.0.0"\nkind = "library"\n')
(trace_work / 'src').mkdir(exist_ok=True)
(trace_work / 'src/main.scoop').write_text('package trace\nfun answer(): Int = 48\n')
# Inspect the ar directory in this measurement script, outside the compiler trace.
# Core has three CBOR metadata members; every other non-manifest member is ELF.
metadata = []
objects = []
with artifact.open('rb') as stream:
    assert stream.read(8) == b'!<arch>\n'
    header = stream.read(60)
    length = int(header[48:58])
    expected = [(0, 68 + length)]
    cursor = 68 + length + (length & 1)
    while cursor < artifact.stat().st_size:
        stream.seek(cursor)
        header = stream.read(60)
        length = int(header[48:58])
        end = cursor + 60 + length + (length & 1)
        member = {'name': header[:16].decode().strip(), 'start': cursor, 'end': end, 'bytes': length}
        if stream.read(4) == b'\x7fELF':
            objects.append(member)
        else:
            metadata.append(member)
            expected.append((cursor, end))
        cursor = end
assert len(metadata) == 3 and objects
args = [str(repo / 'target/m48-summary-reader/release/scoopc'), 'build', str(trace_work),
        '--target', 'x86_64-unknown-linux-gnu', '--direct-slib', str(artifact),
        '--out-slib', str(trace_work / 'result.slib'), '--sysroot', str(work / 'sysroot')]
trace = base / 'logs/file-reader-gnu-compile.trace'
result = subprocess.run(['strace', '-f', '-yy', '-s', '128', '-e',
                         'trace=openat,read,pread64,lseek,close,execve', '-o', str(trace), *args],
                        cwd=repo, capture_output=True)
(base / 'logs/file-reader-gnu-compile.stderr').write_bytes(result.stderr)
result.check_returncode()
positions = {}
reads = []
opens = 0
for line in trace.read_text().splitlines():
    if 'openat(' in line and '"' + str(artifact) + '"' in line:
        opens += 1
    if str(artifact) + '>' not in line:
        continue
    match = re.search(r'^(\d+)\s+(read|lseek|pread64)\((\d+)<', line)
    if not match:
        continue
    pid, operation, fd = match.groups()
    key = (pid, fd)
    returned = re.search(r'= (\d+)\s*$', line)
    assert returned, line
    count = int(returned[1])
    if operation == 'lseek':
        positions[key] = count
    else:
        assert operation == 'read', line
        start = positions.get(key, 0)
        if count:
            reads.append((start, start + count))
        positions[key] = start + count
merged = []
for start, end in sorted(reads):
    if merged and start == merged[-1][1]:
        merged[-1][1] = end
    else:
        merged.append([start, end])
expected.sort()
# Adjacent requested members are allowed to form a single continuous range.
expected_merged = []
for start, end in expected:
    if expected_merged and start == expected_merged[-1][1]:
        expected_merged[-1][1] = end
    else:
        expected_merged.append([start, end])
summary = {'argv': args, 'artifact': str(artifact), 'artifact_bytes': artifact.stat().st_size,
           'opens': opens, 'bytes_read': sum(end-start for start,end in reads),
           'metadata_members': metadata, 'unread_object_members': len(objects),
           'expected_read_ranges': expected_merged, 'actual_read_ranges': merged}
(base / 'logs/file-reader-gnu-compile.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary, indent=2))
assert opens == 1 and merged == expected_merged
assert summary['bytes_read'] < summary['artifact_bytes']
