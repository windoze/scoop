import subprocess
from pathlib import Path

repo = Path.home() / 'repos/scoop'
base = repo / 'target/m48-isolation-validation'
logs = base / 'logs'
target = 'target/m48-summary-reader'
names = ['cli-core-default-source-and-artifact', 'cli-core-locator-cache',
         'generic-siblings-combined', 'm33-native-c-artifacts',
         'm33-gc-leaf-artifacts', 'm46-serialize-artifacts',
         'program-link-input-errors', 'm33-sysroot-reject-*']

def run(tag, args):
    path = logs / f'file-reader-{tag}.log'
    print(f'Starting {tag}', flush=True)
    with path.open('w') as output:
        result = subprocess.run(args, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
    print(f'{tag}: exit={result.returncode}\n' + '\n'.join(path.read_text().splitlines()[-4:]), flush=True)
    result.check_returncode()

run('linux-fmt', ['cargo', 'fmt', '--all', '--check'])
run('linux-clippy', ['cargo', 'clippy', '--workspace', '--all-targets', '--target-dir', target, '-j', '2'])
run('linux-slib', ['cargo', 'test', '-p', 'scoop-slib', '--lib', '--target-dir', target, '-j', '2'])
for label, test in [('inputs', 'request::preflight::tests::inputs'),
                    ('load', 'request::preflight::dependencies::load::tests')]:
    run('linux-' + label, ['cargo', 'test', '-p', 'scoopc', '--lib', '--target-dir', target, '-j', '2', test])
run('linux-release', ['cargo', 'build', '--release', '--target-dir', target, '-j', '2', '-p', 'scoop', '-p', 'scoopc', '-p', 'scoop-linker', '--bins'])
for label in ('gnu', 'musl'):
    work = base / f'file-reader-{label}-cli'
    args = ['python3', 'tests/run_fixtures.py', '--scoop', target + '/release/scoop',
            '--scoopc', target + '/release/scoopc', '--scoop-link', target + '/release/scoop-link',
            '--target', f'x86_64-unknown-linux-{label}', '--jobs', '3', '--work-dir', str(work), '--keep']
    for name in names:
        args += ['--filter', name]
    run(label + '-cli', args)
    (logs / f'file-reader-{label}-cli.json').write_bytes((work / 'report.json').read_bytes())
