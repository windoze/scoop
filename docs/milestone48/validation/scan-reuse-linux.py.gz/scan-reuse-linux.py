import json
import subprocess
from pathlib import Path
repo = Path.home() / "repos/scoop"
base = repo / "target/m48-isolation-validation"
names = ['m27-context-artifacts', 'm27-context-basic', 'm27-context-coroutine-exits', 'm31-ssa-roots', 'm32-roots-artifacts', 'm33-scoped-data-artifacts', 'm46-serialize-artifacts']
for label in ("gnu", "musl"):
    work = base / f"scan-reuse-{label}-cli"
    log = base / "logs" / f"scan-reuse-{label}-cli.log"
    args = ["python3", "tests/run_fixtures.py", "--scoop", "target/m48-summary-reader/release/scoop", "--scoopc", "target/m48-summary-reader/release/scoopc", "--scoop-link", "target/m48-summary-reader/release/scoop-link", "--target", f"x86_64-unknown-linux-{label}", "--jobs", "3", "--work-dir", str(work), "--keep"]
    for name in names:
        args += ["--filter", name]
    print(f"Starting {label}: {len(names)} selections", flush=True)
    with log.open("w") as output:
        result = subprocess.run(args, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
    print(f"{label}: exit={result.returncode}", flush=True)
    print("\n".join(log.read_text().splitlines()[-4:]), flush=True)
    result.check_returncode()
    (base / "logs" / f"scan-reuse-{label}-cli.json").write_bytes((work / "report.json").read_bytes())
