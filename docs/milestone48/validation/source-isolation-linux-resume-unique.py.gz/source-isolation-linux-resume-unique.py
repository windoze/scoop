"""Resume retained fixture results with distinct source paths for every chunk."""
import json
import shutil
import subprocess
from pathlib import Path

repo = Path.home() / 'repos/scoop'
base = repo / 'target/m48-isolation-validation'
logs = base / 'logs'
names = json.loads(Path('/tmp/scoop-m48-isolation-impacted-names.json').read_text())

for label in ('gnu', 'musl'):
    shared = base / f'source-isolation-{label}-resume'
    (shared / 'cache').mkdir(parents=True, exist_ok=True)
    if not (shared / 'sysroot').exists():
        shutil.copytree(repo / 'sysroot', shared / 'sysroot', symlinks=True)
    done = set(json.loads((base / f'{label}-passed-first.json').read_text()))
    reports = list(logs.glob(f'source-isolation-{label}-resume-*.json'))
    reports += list(logs.glob(f'source-isolation-{label}-unique-*.json'))
    reader = logs / f'reader-hashes-{label}-cli.json'
    if reader.exists():
        reports.append(reader)
    for path in reports:
        report = json.loads(path.read_text())
        done.update(row['name'] for row in report['results']
                    if row['status'] in ('passed', 'inapplicable'))
    remaining = [name for name in names if name not in done]
    for offset in range(0, len(remaining), 200):
        tag = f'source-isolation-{label}-unique-{offset // 200 + 1:02}'
        work = base / tag
        work.mkdir(exist_ok=False)
        # Keep reusable inputs while never assigning a prior case path to new inputs.
        for directory in ('cache', 'sysroot'):
            (work / directory).symlink_to(shared / directory, target_is_directory=True)
        log = logs / f'{tag}.log'
        args = ['python3', 'tests/run_fixtures.py', '--scoop', 'target/release/scoop',
                '--scoopc', 'target/release/scoopc', '--scoop-link', 'target/release/scoop-link',
                '--target', f'x86_64-unknown-linux-{label}', '--jobs', '6',
                '--work-dir', str(work), '--keep']
        selected = remaining[offset:offset + 200]
        for name in selected:
            args += ['--filter', name]
        print(f'Starting {tag}: {len(selected)} selections', flush=True)
        with log.open('w') as output:
            result = subprocess.run(args, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
        print(f'{tag}: exit={result.returncode}', flush=True)
        print('\n'.join(log.read_text().splitlines()[-4:]), flush=True)
        report_path = work / 'report.json'
        if report_path.exists():
            (logs / f'{tag}.json').write_bytes(report_path.read_bytes())
        result.check_returncode()
        # Children have exited; reports, source inputs and cache remain elsewhere.
        shutil.rmtree(work / 'cases')
