"""Trace existing successful CLI cases with their exact fixture configuration."""
import json
import os
import re
import subprocess
import sys
import tomllib
from pathlib import Path
from types import SimpleNamespace

repo = Path.cwd()
sys.path.insert(0, str(repo / 'tests'))
from fixture_runner.cli import arguments, environment
from fixture_runner.values import argv_values, expand

libc = sys.argv[1]
target = f'x86_64-unknown-linux-{libc}'
base = Path(f'/tmp/scoop-m48-executable-{libc}-run-final')
report = json.loads((base / 'report.json').read_text())
assert report['counts'].get('failed', 0) == 0, report['counts']
args = arguments(['--target', target, '--cc', '/usr/bin/musl-gcc' if libc == 'musl' else '/usr/bin/gcc', '--scoop', 'target/release/scoop', '--scoopc', 'target/release/scoopc', '--scoop-link', 'target/release/scoop-link'])


def case(name, variant):
    fixture = repo / 'tests/fixtures' / name
    data = tomllib.loads((fixture / 'fixture.toml').read_text())
    index = next(i for i, result in enumerate(report['results']) if result['name'] == name)
    work = base / 'cases' / str(index) / variant
    context = environment(repo, base, [SimpleNamespace(data=data)], args)
    context |= {'fixture': str(fixture), 'work': str(work), 'profile': variant, 'variant': variant}
    context |= expand(data.get('vars', {}), context)
    return data, context, work


def snapshot(work):
    paths = list((work / 'cache/executables-v1').glob('*.json'))
    paths += list((work / 'cache/executables-v1').glob('program-*/program'))
    for root in ['target', 'outputs']:
        paths += [p for p in (work / root).rglob('*') if p.is_file()]
    return {str(p): (p.stat().st_size, p.stat().st_mtime_ns) for p in paths}


summaries = []
for name, variant, step_name, mode, expected_exit in [
    ('m48-executable-record', 'normal', 'debug_again', 'build', 0),
    ('m48-executable-record', 'normal', 'run_warm', 'run', 44),
    ('m43-test-selection', 'debug', 'first', 'test', 0),
]:
    data, context, work = case(name, variant)
    step = next(s for s in data['steps'] if s['name'] == step_name)
    argv = argv_values(step['argv'], context)
    prefix = Path(f'/tmp/scoop-m48-executable-{libc}-{mode}-warm')
    if mode in {'build', 'test'}:
        prepared = subprocess.run(argv, cwd=work, capture_output=True)
        Path(str(prefix) + '.prepare.stderr').write_bytes(prepared.stderr)
        assert prepared.returncode == expected_exit, prepared.stderr
    before = snapshot(work)
    result = subprocess.run(['strace', '-f', '-s', '500', '-e', 'trace=%file,process', '-o', str(prefix) + '.trace', *argv], cwd=work, capture_output=True)
    Path(str(prefix) + '.stderr').write_bytes(result.stderr)
    Path(str(prefix) + '.stdout').write_bytes(result.stdout)
    assert result.returncode == expected_exit, result.stderr
    records = [json.loads(line) for line in result.stderr.splitlines()]
    build = next(item for item in records if item.get('kind') == 'executable')
    children = len(build['observations']['child_invocations'])
    trace = Path(str(prefix) + '.trace').read_text()
    execs = [line for line in trace.splitlines() if 'execve(' in line]
    opens = [line for line in trace.splitlines() if re.search(r'\bopen(?:at|at2)?\(', line)]
    input_opens = [line for line in opens if re.search(r'\.(?:scoop|slib|o|c|cpp|cxx|h|hpp|tbd)"|/Cone\.toml"|/program-[^/]+/program"', line)]
    executable_opens = [line for line in opens if '"' + build['output'] + '"' in line]
    renames = [line for line in trace.splitlines() if re.search(r'\brename(?:at|at2)?\(', line)]
    assert children == 0, children
    assert len(execs) == (1 if mode == 'build' else 2), execs
    assert not input_opens and not executable_opens, input_opens + executable_opens
    assert snapshot(work) == before, 'generated outputs changed'
    if mode == 'build':
        assert not renames, renames
    summaries.append({'mode': mode, 'argv': [os.fsdecode(x) for x in argv], 'exit': result.returncode, 'scoopc_children': children, 'execve': execs, 'input_content_opens': len(input_opens), 'executable_content_opens': len(executable_opens), 'renames': len(renames), 'outputs_unchanged': True})
Path(f'/tmp/scoop-m48-executable-{libc}-warm-summary.json').write_text(json.dumps(summaries, indent=2) + '\n')
print(json.dumps(summaries, indent=2))

if libc == 'gnu':
    import shutil

    data, context, work = case('m48-executable-record', 'normal')
    step = next(s for s in data['steps'] if s['name'] == 'debug_again')
    argv = argv_values(step['argv'], context)
    tools = work / 'link-tools-real'
    tools.mkdir(exist_ok=True)
    actual_ld = Path(shutil.which('ld')).resolve()
    calls = tools / 'calls'
    actual_cc = Path('/usr/bin/gcc').resolve()
    cc = tools / 'gcc'
    cc.write_text(f'#!/bin/sh\nexec "{actual_cc}" -B "{tools}/" "$@"\n')
    cc.chmod(0o755)
    argv[argv.index(b'--cc') + 1] = os.fsencode(cc)
    for name in ['first', 'second']:
        wrapper = tools / name
        wrapper.write_text(f'#!/bin/sh\necho {name} >> "{calls}"\nexec "{actual_ld}" "$@"\n')
        wrapper.chmod(0o755)
    alias = tools / 'ld'
    alias.symlink_to(tools / 'first')
    env = dict(os.environ, PATH=str(tools) + os.pathsep + os.environ['PATH'])
    measurements = []
    for phase in ['selected', 'warm', 'retargeted', 'retargeted-warm']:
        if phase == 'retargeted':
            alias.unlink()
            alias.symlink_to(tools / 'second')
        result = subprocess.run(argv, cwd=work, env=env, capture_output=True)
        Path(f'/tmp/scoop-m48-executable-gnu-ld-{phase}.stderr').write_bytes(result.stderr)
        assert result.returncode == 0, result.stderr
        built = next(json.loads(line) for line in result.stderr.splitlines() if json.loads(line).get('kind') == 'executable')
        row = {'phase': phase, 'children': len(built['observations']['child_invocations']), 'ld_calls': len(calls.read_text().splitlines()), 'executables': len(list((work / 'cache/executables-v1').glob('program-*/program')))}
        if phase != 'selected':
            assert row['children'] == 0, row
        if 'warm' in phase:
            assert row['ld_calls'] == measurements[-1]['ld_calls'], (measurements, row)
            assert row['executables'] == measurements[-1]['executables'], (measurements, row)
        elif phase == 'retargeted':
            assert row['ld_calls'] > measurements[-1]['ld_calls'], (measurements, row)
            assert row['executables'] == measurements[-1]['executables'] + 1, (measurements, row)
        assert subprocess.run([built['output']]).returncode == 44
        measurements.append(row)
    Path('/tmp/scoop-m48-executable-gnu-ld-summary.json').write_text(json.dumps(measurements, indent=2) + '\n')
    print(json.dumps(measurements, indent=2))
