import subprocess
from pathlib import Path
repo = Path('/Users/chenxu/repos/scoop')
names = ['program-link-sdk-native', 'program-link-native-effect-conflict', 'program-link-native-missing', 'program-link-native-library-required', 'program-link-native-kind-conflict', 'program-link-native-reserved', 'program-link-unused-extern-conflict']
args = ['python3', 'tests/run_fixtures.py', '--scoop', 'target/release/scoop', '--scoopc', 'target/release/scoopc', '--scoop-link', 'target/release/scoop-link', '--target', 'aarch64-apple-darwin', '--jobs', '4', '--work-dir', 'target/m48-link-inputs-native-final-darwin', '--keep']
for name in names:
    args += ['--filter', name]
with Path('/tmp/scoop-m48-link-inputs-native-darwin-cli.log').open('w') as output:
    result = subprocess.run(args, cwd=repo, stdout=output, stderr=subprocess.STDOUT)
print('exit:', result.returncode)
result.check_returncode()
