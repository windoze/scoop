import os,subprocess
from pathlib import Path
repo=Path('/Users/chenxu/repos/scoop')
def run(tag,args):
 path=Path('/tmp/scoop-m48-provider-data-'+tag+'.log')
 print('Starting '+tag,flush=True)
 with path.open('w') as output: result=subprocess.run(args,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
 print(tag+': exit='+str(result.returncode)+'\n'+'\n'.join(path.read_text().splitlines()[-4:]),flush=True)
 result.check_returncode()
run('darwin-shape',['cargo','test','-p','scoop-lir','--lib','shape_link'])
run('darwin-closure',['cargo','test','-p','scoop-slib','--lib','link_object::layout'])
run('darwin-release',['cargo','build','--release','-p','scoop','-p','scoopc','-p','scoop-linker','--bins'])
os.environ['SCOOP_TEST_PAIRED_SCOOPC']=str(repo/'target/release/scoopc')
run('darwin-generic',['cargo','test','-p','scoopc','--lib','actual_generic_library_emits_shared_odr_objects'])
names=['generic-siblings-combined','generic-siblings-adapters-combined','generic-odr-conflicts-conflict','program-link-basic','runtime-images-ordinary','runtime-images-schedule-root','imported-class-combined','imported-class-structural-box-combined','imported-class-initialization-combined','imported-class-interface-parent','imported-class-property-updates','imported-class-value-interface-enum','m33-native-c-artifacts','m46-serialize-artifacts','m43-test-purpose-generated','m48-object-files']
args=['python3','tests/run_fixtures.py','--scoop','target/release/scoop','--scoopc','target/release/scoopc','--scoop-link','target/release/scoop-link','--target','aarch64-apple-darwin','--jobs','4','--work-dir','target/m48-provider-data-final-darwin','--keep']
for name in names: args+=['--filter',name]
run('darwin-cli',args)
