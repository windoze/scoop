import subprocess
from pathlib import Path

repo=Path.home()/'repos/scoop'
base=repo/'target/m48-isolation-validation'
logs=base/'logs'
target='target/m48-summary-reader'
names=['cli-core-default-source-and-artifact','generic-siblings-combined',
       'generic-odr-conflicts-conflict','generic-odr-conflicts-strings-conflict',
       'm33-native-c-artifacts','m33-gc-leaf-artifacts','m46-serialize-artifacts',
       'm48-object-files','program-link-input-errors']

def run(tag,args):
    path=logs/f'compile-definitions-{tag}.log'
    print(f'Starting {tag}',flush=True)
    with path.open('w') as output:
        result=subprocess.run(args,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
    print(f'{tag}: exit={result.returncode}\n'+'\n'.join(path.read_text().splitlines()[-4:]),flush=True)
    result.check_returncode()

run('linux-fmt',['cargo','fmt','--all','--check'])
run('linux-clippy',['cargo','clippy','--workspace','--all-targets','--target-dir',target,'-j','2'])
run('linux-slib',['cargo','test','-p','scoop-slib','--lib','--target-dir',target,'-j','2'])
for label,test in [('formal','formal_pipeline_publishes_manifest_library_and_executable_artifacts'),
                   ('odr','actual_duplicate_generic_members_accept_different_optimization')]:
    run('linux-'+label,['cargo','test','-p','scoopc','--lib','--target-dir',target,'-j','2',test])
run('linux-release',['cargo','build','--release','--target-dir',target,'-j','2','-p','scoop','-p','scoopc','-p','scoop-linker','--bins'])
for label in ('gnu','musl'):
    work=base/f'compile-definitions-{label}-cli'
    args=['python3','tests/run_fixtures.py','--scoop',target+'/release/scoop',
          '--scoopc',target+'/release/scoopc','--scoop-link',target+'/release/scoop-link',
          '--target',f'x86_64-unknown-linux-{label}','--jobs','3','--work-dir',str(work),'--keep']
    for name in names:
        args+=['--filter',name]
    run(label+'-cli',args)
    (logs/f'compile-definitions-{label}-cli.json').write_bytes((work/'report.json').read_bytes())
