"""Exercise actual default sysroot changes through the standalone link CLI."""
import json
import os
import shutil
import subprocess
from pathlib import Path

repo = Path.cwd()
built = next(json.loads(line) for line in Path('/tmp/scoop-m48-final-tools-gnu-changed.stderr').read_text().splitlines() if json.loads(line).get('kind') == 'executable')
root = Path('/tmp/scoop-m48-final-tools-config')
root.mkdir()
cache = root / 'cache'
output = root / 'program'
argv = [str(repo / 'target/release/scoop-link'), '--root-slib', built['root']['path'],
        '--runtime-objects', built['runtime_index'], '--target', 'x86_64-unknown-linux-gnu',
        '--cache-dir', str(cache), '-o', str(output)]
for dependency in built['dependencies']:
    argv += ['--dep-slib', dependency['path']]
env = dict(os.environ, SCOOP_SYSROOT=str(repo / 'sysroot'))

def invoke(label):
    result = subprocess.run(argv, env=env, capture_output=True)
    (root / f'{label}.stderr').write_bytes(result.stderr)
    (root / f'{label}.stdout').write_bytes(result.stdout)
    return result

def records():
    return {str(p): [p.stat().st_size, p.stat().st_mtime_ns] for p in sorted(cache.glob('final-tools-v1/*.json'))}

first = invoke('default')
assert first.returncode == 0, first.stderr
assert subprocess.run([output]).returncode == 49
before = records()
assert len(before) == 1, before
output_before = output.stat().st_mtime_ns
original = repo / 'sysroot/native/x86_64-unknown-linux-gnu/unwind'
prefix = root / 'other/native/x86_64-unknown-linux-gnu/unwind'
(prefix / 'include').mkdir(parents=True)
(prefix / 'lib').mkdir()
shutil.copyfile(original / 'lib/libunwind.a', prefix / 'lib/libunwind.a')
for header in (original / 'include').iterdir():
    if header.name != 'unwind.h':
        (prefix / 'include' / header.name).symlink_to(header)
selected = prefix / 'include/unwind.h'
selected.write_text('#error selected_default_sysroot_changed\n')
env['SCOOP_SYSROOT'] = str(root / 'other')
failed = invoke('changed-invalid')
assert failed.returncode != 0 and b'selected_default_sysroot_changed' in failed.stderr, failed
assert before == records()
assert output.stat().st_mtime_ns == output_before
shutil.copyfile(original / 'include/unwind.h', selected)
updated = invoke('changed-valid')
assert updated.returncode == 0, updated.stderr
assert subprocess.run([output]).returncode == 49
assert len(records()) == 2
summary = {'argv': argv, 'record_counts': [1, 1, 2], 'exits': [first.returncode, failed.returncode, updated.returncode], 'program_exit': 49, 'failure_preserved_records_and_output': True}
Path('/tmp/scoop-m48-final-tools-config-summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary))
