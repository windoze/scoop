// Copyright 2019 Google LLC
// Use of this source code is governed by a BSD-style license that can be found in the LICENSE file.
#include "tools/fiddle/examples.h"
REG_FIDDLE(Canvas_skew, 256, 256, false, 0) {
void draw(SkCanvas* canvas) {
    SkPaint paint;
    SkFont font(fontMgr->matchFamilyStyle(nullptr, {}), 128);
    canvas->translate(30, 130);
    canvas->save();
    canvas->skew(-.5, 0);
    canvas->drawString("A1", 0, 0, font, paint);
    canvas->restore();
    canvas->save();
    canvas->skew(0, .5);
    paint.setColor(SK_ColorRED);
    canvas->drawString("A1", 0, 0, font, paint);
    canvas->restore();
    canvas->skew(-.5, .5);
    paint.setColor(SK_ColorBLUE);
    canvas->drawString("A1", 0, 0, font, paint);
}
}  // END FIDDLE
