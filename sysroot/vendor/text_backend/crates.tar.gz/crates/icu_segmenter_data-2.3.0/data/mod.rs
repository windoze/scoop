// @generated
include!("segmenter_break_sentence_v2.rs.data");
include!("segmenter_break_sentence_v1.rs.data");
include!("segmenter_dictionary_auto_v1.rs.data");
include!("segmenter_unihan_radical_v1.rs.data");
include!("segmenter_break_grapheme_cluster_v1.rs.data");
include!("segmenter_dictionary_extended_v1.rs.data");
include!("segmenter_break_line_v2.rs.data");
include!("segmenter_break_line_v1.rs.data");
include!("segmenter_break_line_v3.rs.data");
include!("segmenter_lstm_auto_v1.rs.data");
include!("segmenter_break_grapheme_cluster_v2.rs.data");
include!("segmenter_break_line_override_v2.rs.data");
include!("segmenter_break_word_v1.rs.data");
include!("segmenter_break_word_v2.rs.data");
include!("segmenter_break_word_override_v1.rs.data");
include!("segmenter_break_sentence_override_v1.rs.data");
include!("segmenter_break_sentence_override_v2.rs.data");
/// Marks a type as a data provider. You can then use macros like
/// `impl_core_helloworld_v1` to add implementations.
///
/// ```ignore
/// struct MyProvider;
/// const _: () = {
///     include!("path/to/generated/macros.rs");
///     make_provider!(MyProvider);
///     impl_core_helloworld_v1!(MyProvider);
/// }
/// ```
#[doc(hidden)]
#[macro_export]
macro_rules! __make_provider {
    ($ name : ty) => {
        #[clippy::msrv = "1.88"]
        impl $name {
            #[allow(dead_code)]
            pub(crate) const MUST_USE_MAKE_PROVIDER_MACRO: () = ();
        }
        icu_provider::marker::impl_data_provider_never_marker!($name);
    };
}
#[doc(inline)]
pub use __make_provider as make_provider;
/// This macro requires the following crates:
/// * `icu`
/// * `icu_provider`
/// * `icu_provider/baked`
/// * `zerovec`
#[allow(unused_macros)]
macro_rules! impl_data_provider {
    ($ provider : ty) => {
        make_provider!($provider);
        impl_segmenter_break_sentence_v2!($provider);
        impl_segmenter_break_sentence_v1!($provider);
        impl_segmenter_dictionary_auto_v1!($provider);
        impl_segmenter_unihan_radical_v1!($provider);
        impl_segmenter_break_grapheme_cluster_v1!($provider);
        impl_segmenter_dictionary_extended_v1!($provider);
        impl_segmenter_break_line_v2!($provider);
        impl_segmenter_break_line_v1!($provider);
        impl_segmenter_break_line_v3!($provider);
        impl_segmenter_lstm_auto_v1!($provider);
        impl_segmenter_break_grapheme_cluster_v2!($provider);
        impl_segmenter_break_line_override_v2!($provider);
        impl_segmenter_break_word_v1!($provider);
        impl_segmenter_break_word_v2!($provider);
        impl_segmenter_break_word_override_v1!($provider);
        impl_segmenter_break_sentence_override_v1!($provider);
        impl_segmenter_break_sentence_override_v2!($provider);
    };
}
