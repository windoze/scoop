/*
 * nghttp2 - HTTP/2 C Library
 *
 * Copyright (c) 2016 Tatsuhiro Tsujikawa
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
#include "base64_test.h"

#include <cstring>

#include "munitxx.h"

#include <nghttp2/nghttp2.h>

#include "base64.h"

using namespace std::literals;

namespace nghttp2 {

namespace {
const MunitTest tests[]{
  munit_void_test(test_base64_encode),
  munit_void_test(test_base64_decode),
  munit_test_end(),
};
} // namespace

const MunitSuite base64_suite{
  .prefix = "/base64",
  .tests = tests,
};

void test_base64_encode(void) {
  {
    std::string in = "\xff";
    auto out = base64::encode(in);
    assert_stdstring_equal("/w==", out);
  }
  {
    std::string in = "\xff\xfe";
    auto out = base64::encode(in);
    assert_stdstring_equal("//4=", out);
  }
  {
    std::string in = "\xff\xfe\xfd";
    auto out = base64::encode(in);
    assert_stdstring_equal("//79", out);
  }
  {
    std::string in = "\xff\xfe\xfd\xfc";
    auto out = base64::encode(in);
    assert_stdstring_equal("//79/A==", out);
  }
}

void test_base64_decode(void) {
  BlockAllocator balloc(4096, 4096);
  {
    auto in = "/w=="sv;
    assert_stdsv_equal("\xff"sv, as_string_view(base64::decode(balloc, in)));
  }
  {
    auto in = "//4="sv;
    assert_stdsv_equal("\xff\xfe"sv,
                       as_string_view(base64::decode(balloc, in)));
  }
  {
    auto in = "//79"sv;
    assert_stdsv_equal("\xff\xfe\xfd"sv,
                       as_string_view(base64::decode(balloc, in)));
  }
  {
    auto in = "//79/A=="sv;
    assert_stdsv_equal("\xff\xfe\xfd\xfc"sv,
                       as_string_view(base64::decode(balloc, in)));
  }
  {
    // we check the number of valid input must be multiples of 4
    auto in = "//79="sv;
    assert_stdsv_equal(""sv, as_string_view(base64::decode(balloc, in)));
  }
  {
    // ending invalid character at the boundary of multiples of 4 is
    // bad
    auto in = "bmdodHRw\n"sv;
    assert_stdsv_equal(""sv, as_string_view(base64::decode(balloc, in)));
  }
  {
    // after seeing '=', subsequent input must be also '='.
    auto in = "//79/A=A"sv;
    assert_stdsv_equal(""sv, as_string_view(base64::decode(balloc, in)));
  }
  {
    // additional '=' at the end is bad
    auto in = "//79/A======"sv;
    assert_stdsv_equal(""sv, as_string_view(base64::decode(balloc, in)));
  }
  {
    // Chars with high bit set
    auto in = "\xCA\xFE\xCA\xCE"sv;
    assert_stdsv_equal(""sv, as_string_view(base64::decode(balloc, in)));
  }
}

} // namespace nghttp2
